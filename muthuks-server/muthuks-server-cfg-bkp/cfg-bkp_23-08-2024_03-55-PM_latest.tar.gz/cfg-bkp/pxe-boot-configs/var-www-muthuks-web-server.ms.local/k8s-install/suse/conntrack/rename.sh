#!/bin/bash
#Run this from SuSE Linux
mkdir /root/conntrack 
wget -P /root/conntrack/ https://ftp.lysator.liu.se/pub/opensuse/source/distribution/leap/15.5/repo/oss/src/conntrack-tools-1.4.5-1.46.src.rpm
rpm -i /root/conntrack/conntrack-tools-1.4.5-1.46.src.rpm
