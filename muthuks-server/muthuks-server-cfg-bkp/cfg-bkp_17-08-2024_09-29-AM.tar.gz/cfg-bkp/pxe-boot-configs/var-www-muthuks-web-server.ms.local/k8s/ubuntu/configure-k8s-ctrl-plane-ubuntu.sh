#!/bin/bash

if [[ "$1" == "-y" ]]
then
	:
else
	while :
	do
		echo
		read  -p "Do you really want to run this script $(basename $0) ? (yes/no) : " v_get_confirmation
		if [[ "$v_get_confirmation" == "yes" ]]
		then
			break
		elif [[ "$v_get_confirmation" == "no" ]]
		then
			echo -e "\nExiting without any changes!\n"
			exit
		else
			echo -e "\nInvalid Input!\n"
			continue
		fi
	done
fi

v_k8s_cfg_dir=/root/configure-k8s-ctrl-plane-ubuntu
v_logs_wget="${v_k8s_cfg_dir}/logs-configure-k8s-ctrl-plane-ubuntu.log"
v_k8s_host=$(hostname -f)
v_containerd_version="1.7.20"
v_runc_version="1.1.13"
v_k8s_version="1.31"
v_calico_version="3.28.1"
v_csi_smb_version="1.15.0"

mkdir -p ${v_k8s_cfg_dir}

clear

{

if ! ping -c 1 google.com &>/dev/null ;then 
	echo -e "\nInternet is down !!! Exiting the setup configure-k8s-ctrl-plane-ubuntu.service !!! \n"
	echo -e "\nYou can start the service configure-k8s-ctrl-plane-ubuntu.service manually once Internet is Up! \n"
	exit
fi

################################## Stage-1 ##################################

if [ ! -f ${v_k8s_cfg_dir}/completed-stage1 ];then

clear

echo -e "\nStarting stage-1 of k8s ctrl-plane node configuration on ${v_k8s_host} . . .\n"

apt-get clean
apt-get update
apt-get upgrade -y

echo -e "\nLoading required kernel modules . . .\n"

modprobe -vv overlay
modprobe -vv br_netfilter

cat > /etc/modules-load.d/kubernetes.conf << EOF
overlay
br_netfilter
EOF


echo -e "\nLoading required kernel parameters . . .\n"

cat > /etc/sysctl.d/kubernetes.conf << EOF
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

sysctl --system


echo -e "\nDownloading container runtime containerd . . ."
echo "(This might take some time depending on the internet speed)"

mkdir ${v_k8s_cfg_dir}/containerd

wget -P ${v_k8s_cfg_dir}/containerd/ https://github.com/containerd/containerd/releases/download/v${v_containerd_version}/containerd-${v_containerd_version}-linux-amd64.tar.gz -a ${v_logs_wget}

echo -e "\nConfiguring containerd . . .\n"

tar Cxzvf ${v_k8s_cfg_dir}/containerd/ ${v_k8s_cfg_dir}/containerd/containerd-${v_containerd_version}-linux-amd64.tar.gz

chmod +x ${v_k8s_cfg_dir}/containerd/bin/*

rsync -avPh ${v_k8s_cfg_dir}/containerd/bin/ /usr/bin/

mkdir -p /etc/containerd

containerd config default > /etc/containerd/config.toml

sed -i "/SystemdCgroup/s/false/true/g" /etc/containerd/config.toml

containerd config dump | grep SystemdCgroup

echo -e "Downloading containerd.service file from github . . .\n"

wget -P /etc/systemd/system/ https://raw.githubusercontent.com/containerd/containerd/main/containerd.service -a ${v_logs_wget}

sed -i  "/ExecStart=/s/\/usr\/local/\/usr/g" /etc/systemd/system/containerd.service

echo -e "\nStarting the containerd.service . . .\n"

systemctl daemon-reload

systemctl enable --now containerd.service

systemctl status containerd.service


echo -e "\nDownloading low-level container runtime runc ( dependency of containerd ) . . ."
echo "(This might take some time depending on the internet speed)"

wget -P /usr/bin/ https://github.com/opencontainers/runc/releases/download/v${v_runc_version}/runc.amd64 -a ${v_logs_wget}

echo -e "\nConfiguring runc . . .\n"
mv /usr/bin/runc.amd64 /usr/bin/runc
chmod +x /usr/bin/runc

runc --version


echo -e "\nCompleted stage-1 of k8s ctrl-plane node configuration on ${v_k8s_host} ! \n"

touch ${v_k8s_cfg_dir}/completed-stage1

sleep 2

fi

################################## Stage-2 ##################################

if [ ! -f ${v_k8s_cfg_dir}/completed-stage2 ];then

clear

echo -e "\nStarting stage-2 of k8s ctrl-plane node configuration on ${v_k8s_host} . . .\n"

echo -e "\nConfiguring k8s deb repository and installing required packages . . .\n"

echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring-v${v_k8s_version}.gpg] https://pkgs.k8s.io/core:/stable:/v${v_k8s_version}/deb/ /" | sudo tee /etc/apt/sources.list.d/kubernetes.list

curl -fsSL https://pkgs.k8s.io/core:/stable:/v${v_k8s_version}/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring-v${v_k8s_version}.gpg

apt-get update

apt-get install -y kubelet kubeadm kubectl

apt-mark hold kubelet kubeadm kubectl

echo -e "Starting kubelet.service . . .\n"

systemctl enable --now kubelet.service

systemctl status kubelet.service

#Below are k8s  ctrl-plane node specific configurations

echo -e "\nPulling required images of k8s core pods . . ."
echo "(This might take considerable amount of time depending on the internet speed)"

nice -n -20 kubeadm config images pull

echo -e "\nStarting cluster creation . . .\n"

#kubeadm init --pod-network-cidr=10.8.0.0/16
kubeadm init

echo -e "\nStarting cluster configuration . . .\n"

echo 'export KUBECONFIG=/etc/kubernetes/admin.conf' >>/root/.bashrc
echo "source <(kubectl completion bash)" >>/root/.bashrc
# shellcheck disable=SC1091
source /root/.bashrc

mkdir -p /root/.kube
cp -i /etc/kubernetes/admin.conf /root/.kube/config
chown root:root /root/.kube/config

while true :
do
	echo -e "\nWaiting for API Server pod to come online . . .\n"
        if ! kubectl get pods -n kube-system | grep kube-apiserver | grep Running
        then
		kubectl get pods -n kube-system | grep kube-apiserver
                continue
        else
                sleep 2
                kubectl get pods -n kube-system | grep kube-apiserver | grep Running
                break
        fi
done

echo -e "\nDownloading the manifest for Calico CNI ( Container Network Interface ) . . .\n"
#Calico CNI ( Container Network Interface )
wget -P ${v_k8s_cfg_dir}/ https://raw.githubusercontent.com/projectcalico/calico/v${v_calico_version}/manifests/calico.yaml -a ${v_logs_wget} 

echo -e "\nConfiguring calico by setting pod network as 10.8.0.0/16 . . .\n"

sed -i -e "/CALICO_IPV4POOL_CIDR/s/ #//g" -e "/192.168.0.0/s/ #//g" ${v_k8s_cfg_dir}/calico.yaml
sed -i "s/192.168.0.0/10.8.0.0/g" ${v_k8s_cfg_dir}/calico.yaml
grep 10.8.0.0 -B 4 ${v_k8s_cfg_dir}/calico.yaml
kubectl apply -f ${v_k8s_cfg_dir}/calico.yaml

##In Case if you want to use tigera operator instead of basic calcio CNI setup
#kubectl create -f https://raw.githubusercontent.com/projectcalico/calico/v${v_calico_version}/manifests/tigera-operator.yaml
#wget -P ${v_k8s_cfg_dir}/  https://raw.githubusercontent.com/projectcalico/calico/v${v_calico_version}/manifests/custom-resources.yaml
#sed -i 's/cidr: 192\.168\.0\.0\/16/cidr: 10.8.0.0\/16/g' ${v_k8s_cfg_dir}/custom-resources.yaml
#kubectl create -f ${v_k8s_cfg_dir}/custom-resources.yaml

echo -e "\nCompleted stage-2 of k8s ctrl-plane node configuration on ${v_k8s_host} ! \n"

kubectl get nodes

echo -e "\nCommand to join worker nodes is located in ${v_k8s_cfg_dir}/worker-node-join-command !! \n"

touch ${v_k8s_cfg_dir}/completed-stage2

sleep 2

fi

clear

echo -e "\nProceeding with post-installation configurations . . .\n"

# Waiting for control plane to become ready
while :
do
	echo -e "\nWaiting for ctrl-plane to get Ready . . .\n"
	if kubectl get nodes | grep -w " Ready " &>/dev/null
	then
		kubectl get nodes
		kubectl get pods -A
		break
	else
		kubectl get nodes
		kubectl get pods -A
		sleep 2
		continue
	fi
done

echo -e "\nInstalling CSI SMB drivers by remote internet connection . . . . . .\n" 
curl -skSL https://raw.githubusercontent.com/kubernetes-csi/csi-driver-smb/v${v_csi_smb_version}/deploy/install-driver.sh | bash -s v${v_csi_smb_version} --

# Wait until all pods are running

while :
do
	echo -e "\nWaiting for CSI SMB pods creation to start . . .\n"
	if kubectl get pods --all-namespaces | grep csi-smb;then break;fi
	sleep 2
done

while :
do
	echo -e "\nWaiting for all the required ctrl-plane pods to come online . . .\n"
	if kubectl get pods --all-namespaces -o jsonpath='{.items[*].status.containerStatuses[*].ready}' | grep false &>/dev/null
	then 
		kubectl get pods --all-namespaces
		sleep 5
		continue
	else 
		echo -e "\nAll the required pods for ctrl-plane are now Running! \n"
		kubectl get pods --all-namespaces
		break
	fi
done

echo -e "\nSuccessfully completed installation and configuration of k8s ctrl-plane node! \n"

kubectl get nodes

if [ -f /scripts_by_muthu/muthuks-server/k8s/k8s-setup-apply.sh ];then
	ln -s /scripts_by_muthu/muthuks-server/k8s/k8s-setup-apply.sh /usr/bin/k8s-apply
fi

if [ -f /scripts_by_muthu/muthuks-server/k8s/k8s-setup-delete.sh ];then
	ln -s /scripts_by_muthu/muthuks-server/k8s/k8s-setup-delete.sh /usr/bin/k8s-delete
fi

systemctl disable configure-k8s-ctrl-plane-ubuntu.service

########################## End of Configuration ####################################

} | tee -a /dev/tty0 ${v_k8s_cfg_dir}/logs-configure-k8s-ctrl-plane-ubuntu.log
