#!/bin/bash
mkdir -p /var/www/muthuks-web-server.ms.local/{{rhel,rocky,almalinux,oraclelinux}-9-4,ubuntu-24-04,opensuse-15-6}
mount -o loop /downloads/rhel-9.4-x86_64-boot.iso /var/www/muthuks-web-server.ms.local/rhel-9-4
mount -o loop /downloads/Rocky-9.4-x86_64-boot.iso /var/www/muthuks-web-server.ms.local/rocky-9-4
mount -o loop /downloads/AlmaLinux-9.4-x86_64-boot.iso /var/www/muthuks-web-server.ms.local/almalinux-9-4
mount -o loop /downloads/OracleLinux-R9-U4-x86_64-boot.iso /var/www/muthuks-web-server.ms.local/oraclelinux-9-4
mount -o loop /downloads/openSUSE-Leap-15.6-DVD-x86_64-Build709.1-Media.iso /var/www/muthuks-web-server.ms.local/opensuse-15-6
#mount -o loop /downloads/ubuntu-24.04-live-server-amd64.iso /var/www/muthuks-web-server.ms.local/ubuntu-24-04
