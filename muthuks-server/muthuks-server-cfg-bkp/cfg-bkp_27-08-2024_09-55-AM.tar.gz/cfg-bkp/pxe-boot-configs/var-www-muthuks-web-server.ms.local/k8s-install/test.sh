#!/bin/bash

fn_curl_version() {
	var_api_url="${1}"
	var_software_name="${2}"
	v_latest_version=$(curl -s -L "${var_api_url}" | jq -r '.tag_name' | tr -d '[:space:]')
	if grep -o <<< "${v_latest_version}" &>/dev/null
	then
		return "${v_latest_version}"
	else
		if [[ "${var_software_name}" == "k8s" ]]
		then
			echo "\nFailed to fetch latest version of "${var_software_name}" ! \n"
			while :
			do
				echo "Login to the host ${var_k8s_host} and switch to directory ${var_k8s_cfg_dir}."
				echo "Refer : https://github.com/kubernetes/kubernetes"
				echo "Create a file ${var_k8s_cfg_dir}/${var_software_name}_version.txt with the version in the format v*.*.*"
				echo "Waiting for 10 seconds to refer the file ${var_k8s_cfg_dir}/${var_software_name}_version.txt . . ."
				sleep 10
				if grep -o "v*.*.*" ${var_k8s_cfg_dir}/${var_software_name}_version.txt &>/dev/null
				then
					v_latest_version
			done
		
		fi
	fi



}

echo -e "\nFetching latest version information of k8s, containerd, runc, calico and csi-driver-smb . . .\n"

var_k8s_version=$(fn_curl_version "https://api.github.com/repos/kubernetes/kubernetes/releases/latest" "k8s")
var_containerd_version=$(fn_curl_version "https://api.github.com/repos/containerd/containerd/releases/latest" "containerd")
var_runc_version=$(fn_curl_version "https://api.github.com/repos/opencontainers/runc/releases/latest" "runc")
var_calico_version=$(fn_curl_version "https://api.github.com/repos/projectcalico/calico/releases/latest" "calico")
var_csi_smb_version=$(fn_curl_version "https://api.github.com/repos/kubernetes-csi/csi-driver-smb/releases/latest" "csi_smb")
