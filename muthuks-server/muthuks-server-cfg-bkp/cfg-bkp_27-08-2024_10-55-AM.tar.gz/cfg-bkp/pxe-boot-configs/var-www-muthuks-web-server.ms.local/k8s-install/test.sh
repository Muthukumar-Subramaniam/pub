#!/bin/bash

fn_curl_version() {

	var_api_url="${1}"
	var_software_name="${2}"
	var_k8s_host="${3}"
	var_k8s_cfg_dir="${4}"
	var_git_repo_url="${5}"

	v_latest_version=$(curl -s -L "${var_api_url}" | jq -r '.tag_name' | tr -d '[:space:]')

	if grep -o "v*.*.*" <<< "${v_latest_version}" &>/dev/null
	then
		echo "${v_latest_version}"
	else
		echo "\nFailed to fetch latest version of "${var_software_name}" ! \n"
		while :
		do
			echo "Login to the host ${var_k8s_host} via ssh and switch to directory ${var_k8s_cfg_dir}."
			echo "Refer : ${var_git_repo_url}"
			echo "Create a file ${var_software_name}_version.txt with the version in the format v*.*.*"
			echo "Waiting for 10 seconds to refer the file ${var_k8s_cfg_dir}/${var_software_name}_version . . ."
			sleep 10

			if grep -o "v*.*.*" ${var_k8s_cfg_dir}/${var_software_name}_version.txt &>/dev/null
			then
				v_latest_version=$(cat "${var_k8s_cfg_dir}"/"${var_software_name}"_version)
				echo "${v_latest_version}"
				
				break
			else
				continue
			fi
		done
		
	fi
}

echo -e "\nFetching latest version information of k8s, containerd, runc, calico and csi-driver-smb . . .\n"

var_k8s_version=$(fn_curl_version "https://api.github.com/repos/kubernetes/kubernetes/releases/latest" "k8s" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/kubernetes/kubernetes")
echo -e "Latest version of k8s is ${var_k8s_version} \n"

var_containerd_version=$(fn_curl_version "https://api.github.com/repos/containerd/containerd/releases/latest" "containerd" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/containerd/containerd")
echo -e "Latest version of containerd is ${var_containerd_version} \n"

var_runc_version=$(fn_curl_version "https://api.github.com/repos/opencontainers/runc/releases/latest" "runc" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/opencontainers/runc")
echo -e "Latest version of runc is ${var_runc_version} \n"

var_calico_version=$(fn_curl_version "https://api.github.com/repos/projectcalico/calico/releases/latest" "calico" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/projectcalico/calico")
echo -e "Latest version of calico is ${var_calico_version} \n"

var_csi_smb_version=$(fn_curl_version "https://api.github.com/repos/kubernetes-csi/csi-driver-smb/releases/latest" "csi_smb" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/kubernetes-csi/csi-driver-smb")
echo -e "Latest version of csi_smb driver is ${var_csi_smb_version} \n"
