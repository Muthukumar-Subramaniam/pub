#!/bin/python
import requests

def get_latest_tag(var_api_url):
  """Fetches the latest tag for a GitHub repository.

  Args:
    repo_owner: The owner of the GitHub repository.
    repo_name: The name of the GitHub repository.

  Returns:
    The latest tag name.
  """

  url = f"{var_api_url}"
  response = requests.get(url)

  if response.status_code == 200:
    data = response.json()
    return data["tag_name"]
  else:
    print("Error fetching latest release:", response.text)
    return None

var_versions_store_dir = "/var/www/muthuks-web-server.ms.local/k8s-install"
api_url_k8s_latest = "https://api.github.com/repos/kubernetes/kubernetes/releases/latest" 
api_url_containerd_latest = "https://api.github.com/repos/containerd/containerd/releases/latest"
api_url_runc_latest = "https://api.github.com/repos/opencontainers/runc/releases/latest"

latest_version_tag_of_k8s = get_latest_tag(api_url_k8s_latest)
if latest_version_tag_of_k8s:
    print("Latest version tag of k8s:", latest_version_tag_of_k8s)
    k8s_version_file_path = f"{var_versions_store_dir}/latest-k8s-version.txt"
    with open(k8s_version_file_path, "w") as f:
      f.write(latest_version_tag_of_k8s)
    print("Latest version tag of k8s is stored in", k8s_version_file_path)
else:
  	print("Failed to fetch latest version tag for k8s.")
