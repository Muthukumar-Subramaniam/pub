#!/bin/bash
var_runc_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/current-runc-version.txt)
var_runc_dir="/var/www/muthuks-web-server.ms.local/k8s-install/local/runc/${var_runc_version}"
mkdir -p "${var_runc_dir}"
wget https://github.com/opencontainers/runc/releases/download/"${var_runc_version}"/runc.amd64 -O "${var_runc_dir}/"runc.amd64
