#!/bin/bash
var_containerd_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/current-containerd-version.txt)
var_containerd_dir="/var/www/muthuks-web-server.ms.local/k8s-install/local/containerd/${var_containerd_version}"
mkdir -p "${var_containerd_dir}"
wget https://github.com/containerd/containerd/releases/download/"${var_containerd_version}"/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz -O "${var_containerd_dir}/"containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz

wget https://raw.githubusercontent.com/containerd/containerd/main/containerd.service -O "${var_containerd_dir}/"containerd.service
