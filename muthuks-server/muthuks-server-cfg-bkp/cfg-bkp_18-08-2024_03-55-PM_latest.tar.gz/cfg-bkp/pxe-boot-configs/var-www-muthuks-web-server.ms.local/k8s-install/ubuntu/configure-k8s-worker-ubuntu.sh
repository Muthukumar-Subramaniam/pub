#!/bin/bash

if [[ "$1" == "-y" ]]
then
	:
else
	while :
	do
		echo
		read  -p "Do you really want to run this script $(basename $0) ? (yes/no) : " v_get_confirmation
		if [[ "$v_get_confirmation" == "yes" ]]
		then
			break
		elif [[ "$v_get_confirmation" == "no" ]]
		then
			echo -e "\nExiting without any changes!\n"
			exit
		else
			echo -e "\nInvalid Input!\n"
			continue
		fi
	done
fi

v_k8s_cfg_dir=/root/configure-k8s-worker-ubuntu
v_logs_wget="${v_k8s_cfg_dir}/logs-configure-k8s-worker-ubuntu.log"
v_k8s_host=$(hostname -f)
v_containerd_version="1.7.20"
v_runc_version="1.1.13"
v_k8s_version="1.31"

mkdir -p ${v_k8s_cfg_dir}

mkdir -p ${v_k8s_cfg_dir}

{

if ! ping -c 1 google.com &>/dev/null ;then
        echo -e "\nInternet is down !!! Exiting the setup configure-k8s-worker-ubuntu.service !!! \n"
        echo -e "\nYou can start the service configure-k8s-worker-ubuntu.service manually once Internet is Up! \n"
	exit
fi

############################## Stage-1 ##############################

if [ ! -f ${v_k8s_cfg_dir}/completed-stage1 ];then

echo -e "\nStarting stage-1 k8s worker node configuration on ${v_k8s_host} . . .\n"

apt-get clean
apt-get update
apt-get upgrade -y

echo -e "\nLoading required kernel modules . . .\n"

modprobe -vv overlay
modprobe -vv br_netfilter

cat > /etc/modules-load.d/kubernetes.conf << EOF
overlay
br_netfilter
EOF


echo -e "\nLoading required kernel parameters . . .\n"

cat > /etc/sysctl.d/kubernetes.conf << EOF
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

sysctl --system

echo -e "\nDownloading container runtime containerd . . ."
echo "(This might take some time depending on the internet speed)"

mkdir ${v_k8s_cfg_dir}/containerd

wget -P ${v_k8s_cfg_dir}/containerd/ https://github.com/containerd/containerd/releases/download/v${v_containerd_version}/containerd-${v_containerd_version}-linux-amd64.tar.gz -a ${v_logs_wget}

echo -e "\nConfiguring containerd . . .\n"

tar Cxzvf ${v_k8s_cfg_dir}/containerd/ ${v_k8s_cfg_dir}/containerd/containerd-${v_containerd_version}-linux-amd64.tar.gz

chmod +x ${v_k8s_cfg_dir}/containerd/bin/*

rsync -avPh ${v_k8s_cfg_dir}/containerd/bin/ /usr/bin/

mkdir -p /etc/containerd

containerd config default > /etc/containerd/config.toml

sed -i "/SystemdCgroup/s/false/true/g" /etc/containerd/config.toml

containerd config dump | grep SystemdCgroup

echo -e "Downloading containerd.service file from github . . .\n"

wget -P /etc/systemd/system/ https://raw.githubusercontent.com/containerd/containerd/main/containerd.service -a ${v_logs_wget}

sed -i  "/ExecStart=/s/\/usr\/local/\/usr/g" /etc/systemd/system/containerd.service

echo -e "\nStarting the containerd.service . . .\n"

systemctl daemon-reload

systemctl enable --now containerd.service

systemctl status containerd.service

echo -e "\nDownloading low-level container runtime runc ( dependency of containerd ) . . ."
echo "(This might take some time depending on the internet speed)"

wget -P /usr/bin/ https://github.com/opencontainers/runc/releases/download/v${v_runc_version}/runc.amd64 -a ${v_logs_wget}

echo -e "\nConfiguring runc . . .\n"
mv /usr/bin/runc.amd64 /usr/bin/runc
chmod +x /usr/bin/runc

runc --version

echo -e "\nCompleted stage-1 k8s worker node configuration on ${v_k8s_host} ! \n"

touch ${v_k8s_cfg_dir}/completed-stage1

sleep 2

fi

################################## Stage-2 ##################################

if [ ! -f ${v_k8s_cfg_dir}/completed-stage2 ];then

echo -e "\nStarting stage-2 k8s worker node configuration on ${v_k8s_host} . . .\n"

echo -e "\nConfiguring k8s rpm repository and installing required packages . . .\n"

echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring-v${v_k8s_version}.gpg] https://pkgs.k8s.io/core:/stable:/v${v_k8s_version}/deb/ /" | sudo tee /etc/apt/sources.list.d/kubernetes.list

curl -fsSL https://pkgs.k8s.io/core:/stable:/v${v_k8s_version}/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring-v${v_k8s_version}.gpg

apt-get update

apt-get install -y kubelet kubeadm kubectl 

apt-mark hold kubelet kubeadm kubectl

echo -e "Starting kubelet.service . . .\n"

systemctl enable --now kubelet.service

systemctl status kubelet.service

echo -e "\nCompleted stage-2 k8s worker node configuration on ${v_k8s_host} ! All done ! \n"

echo -e "\nIgnore if kubelet.service service is not running! \n"
echo -e "\nThe kubelet.service will start automatically when this worker node is joined with ctrl-plane node! \n"
echo -e "\nFrom ctrl-plane node,\nRun \"kubeadm token create --print-join-command\" to create join command.\n"

touch ${v_k8s_cfg_dir}/completed-stage2

systemctl disable configure-k8s-worker-ubuntu.service

fi

} | tee -a /dev/tty0 ${v_k8s_cfg_dir}/logs-configure-k8s-worker-ubuntu.log
