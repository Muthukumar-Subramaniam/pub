#!/bin/bash
var_containerd_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/latest-containerd-version.txt)
var_runc_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/latest-runc-version.txt)
var_containerd_dir="/var/www/muthuks-web-server.ms.local/k8s-install/local/containerd/${var_containerd_version}"
var_runc_dir="/var/www/muthuks-web-server.ms.local/k8s-install/local/runc/${var_runc_version}"

rm -rf /var/www/muthuks-web-server.ms.local/k8s-install/local/containerd/*
mkdir -p "${var_containerd_dir}"
wget https://github.com/containerd/containerd/releases/download/"${var_containerd_version}"/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz -O "${var_containerd_dir}/"containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz
wget https://raw.githubusercontent.com/containerd/containerd/main/containerd.service -O "${var_containerd_dir}/"containerd.service

rm -rf /var/www/muthuks-web-server.ms.local/k8s-install/local/runc/*
mkdir -p "${var_runc_dir}"
rm -rf "${var_runc_dir}"/*
wget https://github.com/opencontainers/runc/releases/download/"${var_runc_version}"/runc.amd64 -O "${var_runc_dir}/"runc.amd64
