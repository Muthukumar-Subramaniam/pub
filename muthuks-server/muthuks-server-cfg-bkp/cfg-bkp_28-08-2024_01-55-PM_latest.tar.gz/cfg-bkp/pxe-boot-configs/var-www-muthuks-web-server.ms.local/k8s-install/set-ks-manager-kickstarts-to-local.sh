#!/bin/bash
var_kickstarts_dir="/var/www/muthuks-web-server.ms.local/ks-manager-kickstarts"
echo -e "\nSetting path k8s-install to k8s-install/local . . .\n"
find "${var_kickstarts_dir}"/ -type f -exec sed -i "s:k8s-install/configure-k8s:k8s-install/local/configure-k8s:g" {} \;
echo -e "\nPath has been updated to local . . .\n"
find "${var_kickstarts_dir}"/ -type f -exec grep k8s-install {} \;
