#!/bin/bash

fn_k8s_main_menu() {
	
	var_input_provided="${1}"
	
	if [[ "${var_input_provided}" == "--ctrl-plane-node" ]]
	then
		var_k8s_node_type='ctrl-plane'

	elif [[  "${var_input_provided}" == "--worker-node" ]]
	then
		var_k8s_node_type='worker'
	else
		echo "Usage: $0 [OPTION] "
		echo "Either configures latest version k8s control plane node or worker node based on provided option."

	fi

}


fn_check_internet_connectivity() {
	while :
	do
		echo -e "\nChecking Internet connectivity as the next step requires it . . ."
		if ! ping -c 1 google.com &>/dev/null
		then 
			echo -e "\nInternet connection is down! "
			echo -e "Waiting for 10 seconds to check again . . .\n"
			sleep 10
			continue
		else
			echo -e "\nInternet connection is active.\n"
			break
		fi
	done
}


fn_set_version_variables() {

	fn_get_latest_version() {
		
		var_api_url="${1}"
		var_software_name="${2}"
		var_git_repo_url="${3}"
		
		fn_check_internet_connectivity
		
		var_latest_version=$(curl -s -L "${var_api_url}" | jq -r '.tag_name' 2>>/dev/null | tr -d '[:space:]')
		
		if [[ ! "${var_latest_version}" =~ v[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+ ]] 
		then
			echo -e "\nFailed to fetch latest version of "${var_software_name}" ! \n"
			
			while :
			do
				echo "Login to the host ${var_k8s_host} via ssh and switch to directory ${var_k8s_cfg_dir}."
				echo "Refer : ${var_git_repo_url}"
				echo "Create a file ${var_software_name}_version.txt with the version in the format v*.*.*"
				echo "Waiting for 5 seconds to refer the file ${var_k8s_cfg_dir}/${var_software_name}_version . . ."
				sleep 5				
				
				if [ -f "${var_k8s_cfg_dir}"/"${var_software_name}"_version ]
				then
					var_latest_version=$(cat "${var_k8s_cfg_dir}"/"${var_software_name}"_version | tr -d '[:space:]' | sed '/^$/d')
				else
					continue
				fi
				
				if [[ "${var_latest_version}" =~ v[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+ ]]
				then
					break
				else
					echo -e "Incorrect format of version in "${var_k8s_cfg_dir}"/"${var_software_name}"_version! \n"
					echo -e "The format should be vMAJOR.MINOR.PATCH ( Semantic Versioning )"
					echo -e "Current version mentioned : $(cat "${var_k8s_cfg_dir}"/"${var_software_name}"_version) \n"
					continue
				fi
			done
						
		fi
	}
	
	echo -e "Fetching latest version information of k8s . . . \n"
	fn_get_latest_version "https://api.github.com/repos/kubernetes/kubernetes/releases/latest" "k8s" "https://github.com/kubernetes/kubernetes"
	var_k8s_version="${var_latest_version}"
	echo -e "Latest version of k8s is ${var_k8s_version} \n"
	
	echo -e "Fetching latest version information of containerd . . . \n"
	fn_get_latest_version "https://api.github.com/repos/containerd/containerd/releases/latest" "containerd" "https://github.com/containerd/containerd"
	var_containerd_version="${var_latest_version}"
	echo -e "Latest version of containerd is ${var_containerd_version} \n"
	
	echo -e "Fetching latest version information of runc . . . \n"
	fn_get_latest_version "https://api.github.com/repos/opencontainers/runc/releases/latest" "runc" "https://github.com/opencontainers/runc"
	var_runc_version="${var_latest_version}"
	echo -e "Latest version of runc is ${var_runc_version} \n"
	
	if [[ "${var_k8s_node_type}" == "ctrl-plane" ]]
	then
		echo -e "Fetching latest version information of calico . . . \n"
		fn_get_latest_version "https://api.github.com/repos/projectcalico/calico/releases/latest" "calico" "https://github.com/projectcalico/calico"
		var_calico_version="${var_latest_version}"
		echo -e "Latest version of calico is ${var_calico_version} \n"
		
		echo -e "Fetching latest version information csi-driver-smb . . . \n"
		fn_get_latest_version "https://api.github.com/repos/kubernetes-csi/csi-driver-smb/releases/latest" "csi_smb" "https://github.com/kubernetes-csi/csi-driver-smb"
		var_csi_smb_version="${var_latest_version}"
		echo -e "Latest version of csi-driver-smb is ${var_csi_smb_version} \n"
	fi
}


fn_stage1_configuration() {
	
	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage1 ]
	then
		clear
		
		echo -e "\nStarting stage-1 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} . . .\n"
		
		echo -e "\nLoading required kernel modules . . .\n"
		
		modprobe -vv overlay
		modprobe -vv br_netfilter

cat << EOF | tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF
		
		echo -e "\nLoading required kernel parameters . . .\n"
		
cat << EOF | tee /etc/sysctl.d/k8s.conf
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF
		
		sysctl --system
		
		fn_check_internet_connectivity
		
		echo -e "\nDownloading container runtime containerd . . ."
		echo "(This might take some time depending on the internet speed)"
		
		mkdir "${var_k8s_cfg_dir}"/containerd
		
		wget -P "${var_k8s_cfg_dir}"/containerd/ https://github.com/containerd/containerd/releases/download/"${var_containerd_version}"/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz -a "${var_logs_file}" 
		
		echo -e "\nConfiguring containerd . . .\n"
		
		tar Cxzvf "${var_k8s_cfg_dir}"/containerd/ "${var_k8s_cfg_dir}"/containerd/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz
		
		chmod +x "${var_k8s_cfg_dir}"/containerd/bin/*
		
		rsync -avPh "${var_k8s_cfg_dir}"/containerd/bin/ /usr/bin/
		
		mkdir -p /etc/containerd
		
		echo -e "\nChecking containerd version . . ."
		
		containerd --version
		
		containerd config default > /etc/containerd/config.toml
		
		sed -i "/SystemdCgroup/s/false/true/g" /etc/containerd/config.toml
		
		containerd config dump | grep SystemdCgroup
		
		fn_check_internet_connectivity
		
		echo -e "Downloading containerd.service file from github . . .\n"
		
		wget -P /etc/systemd/system/ https://raw.githubusercontent.com/containerd/containerd/main/containerd.service -a "${var_logs_file}"
		
		sed -i  "/ExecStart=/s/\/usr\/local/\/usr/g" /etc/systemd/system/containerd.service
		
		echo -e "\nStarting the containerd.service . . .\n"
		
		systemctl daemon-reload
		
		systemctl enable --now containerd.service
		
		systemctl status containerd.service
		
		fn_check_internet_connectivity
		
		echo -e "\nDownloading low-level container runtime runc ( dependency of containerd ) . . ."
		echo "(This might take some time depending on the internet speed)"
		
		wget -P /usr/bin/ https://github.com/opencontainers/runc/releases/download/"${var_runc_version}"/runc.amd64 -a "${var_logs_file}" 
		
		echo -e "\nConfiguring runc . . .\n"
		mv /usr/bin/runc.amd64 /usr/bin/runc
		chmod +x /usr/bin/runc
		
		runc --version
		
		echo -e "\nCompleted stage-1 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} ! \n"
		
		touch "${var_k8s_cfg_dir}"/completed-stage1
		
		sleep 2
		
	fi
}


fn_stage2_for_redhat_based() {
	
	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage2 ]
	then
		
		clear
		
		echo -e "\nStarting stage-2 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} . . .\n"
		
		fn_check_internet_connectivity
		
		echo -e "\nConfiguring k8s rpm repository and installing required packages . . .\n"
		
		var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
		var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
		var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"
		
cat << EOF | tee /etc/yum.repos.d/k8s.repo
[k8s-${var_k8s_version_major_minor}]
name=k8s-${var_k8s_version_major_minor}
baseurl=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/repodata/repomd.xml.key
exclude=kubelet kubeadm kubectl
EOF
		
		dnf makecache
		dnf install -y kubelet kubeadm kubectl --disableexcludes=k8s-"${var_k8s_version_major_minor}"
		
		echo -e "\nCompleted stage-2 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} ! \n"
		
		touch "${var_k8s_cfg_dir}"/completed-stage2
	fi
}


fn_stage2_for_debian_based() {
			
	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage2 ]
	then
		clear
		
		echo -e "\nStarting stage-2 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} . . .\n"
			
		fn_check_internet_connectivity
			
		echo -e "\nConfiguring k8s deb repository and installing required packages . . .\n"
			
		var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
		var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
		var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"
			
		echo "deb [signed-by=/etc/apt/keyrings/k8s-apt-keyring-${var_k8s_version_major_minor}.gpg] https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/deb/ /" | sudo tee /etc/apt/sources.list.d/k8s.list
			
		curl -fsSL https://pkgs.k8s.io/core:/stable:/"${var_k8s_version_major_minor}"/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/k8s-apt-keyring-"${var_k8s_version_major_minor}".gpg
			
		apt-get update
		
		apt-get install -y kubelet kubeadm kubectl
		
		apt-mark hold kubelet kubeadm kubectl
		
		echo -e "\nCompleted stage-2 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} ! \n"
		
		touch "${var_k8s_cfg_dir}"/completed-stage2
	fi
}


fn_stage2_for_suse_based() {
	
	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage2 ]
	then
		clear
		
		echo -e "\nStarting stage-2 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} . . .\n"
		
		fn_check_internet_connectivity
		
		echo -e "\nConfiguring k8s rpm repository and installing required packages . . .\n"
		
		var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
		var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
		var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"
		
cat <<EOF | tee /etc/zypp/repos.d/k8s.repo
[k8s-${var_k8s_version_major_minor}]
name=k8s-${var_k8s_version_major_minor}
baseurl=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/repodata/repomd.xml.key
[conntrack-for-suse]
name=conntrack-for-suse
baseurl=https://ks-manager-provided-web-server-name/k8s-install/suse/rpm/
enabled=1
gpgcheck=0
EOF
		
		fn_check_internet_connectivity
		
		zypper --gpg-auto-import-keys refresh
		
		fn_check_internet_connectivity
		
		zypper install -y kubeadm kubectl kubelet 	
		
		zypper addlock kubeadm kubectl kubelet
		
		zypper ll
		
		echo -e "\nCompleted stage-2 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} ! \n"
		
		touch "${var_k8s_cfg_dir}"/completed-stage2
	fi
}


fn_stage3_configuration() {
	
	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage3 ]
	then
		echo -e "\nStarting stage-3 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} . . .\n"

		echo -e "Starting kubelet.service . . .\n"
		
		systemctl enable --now kubelet.service
		
		systemctl status kubelet.service
		
		#Below are k8s  ${var_k8s_node_type} node specific configurations
		
		fn_check_internet_connectivity
		
		echo -e "\nPulling required images of k8s core pods . . ."
		echo -e "(This might take considerable amount of time depending on the internet speed)\n"
		
		nice -n -20 kubeadm config images pull
		
		echo -e "\nStarting cluster creation . . .\n"
		
		#kubeadm init --pod-network-cidr=10.8.0.0/16
		kubeadm init
		
		echo -e "\nStarting cluster configuration . . .\n"
		
		echo 'export KUBECONFIG=/etc/kubernetes/admin.conf' >>/root/.bashrc
		echo "source <(kubectl completion bash)" >>/root/.bashrc
		# shellcheck disable=SC1091
		source /root/.bashrc
		
		mkdir -p /root/.kube
		cp -i /etc/kubernetes/admin.conf /root/.kube/config
		chown root:root /root/.kube/config
		
		while true :
		do
			echo -e "\nWaiting for API Server pod to come online . . .\n"
        		if ! kubectl get pods -n kube-system | grep kube-apiserver | grep Running
        		then
				kubectl get pods -n kube-system | grep kube-apiserver
                		sleep 2
                		continue
        		else
                		kubectl get pods -n kube-system | grep kube-apiserver | grep Running
                		break
        		fi
		done
		
		fn_check_internet_connectivity
		
		echo -e "\nDownloading the manifest for Calico CNI ( Container Network Interface ) . . .\n"
		
		#Calico CNI ( Container Network Interface )
		wget -P "${var_k8s_cfg_dir}"/ https://raw.githubusercontent.com/projectcalico/calico/"${var_calico_version}"/manifests/calico.yaml -a "${var_logs_file}"
		
		echo -e "\nConfiguring calico by setting pod network as 10.8.0.0/16 . . .\n"
			
		sed -i -e "/CALICO_IPV4POOL_CIDR/s/ #//g" -e "/192.168.0.0/s/ #//g" "${var_k8s_cfg_dir}"/calico.yaml
		sed -i "s/192.168.0.0/10.8.0.0/g" "${var_k8s_cfg_dir}"/calico.yaml
		grep 10.8.0.0 -B 4 "${var_k8s_cfg_dir}"/calico.yaml
		kubectl apply -f "${var_k8s_cfg_dir}"/calico.yaml
			
		#In Case if you want to use tigera operator instead of basic calcio CNI setup
		#kubectl create -f https://raw.githubusercontent.com/projectcalico/calico/${var_calico_version}/manifests/tigera-operator.yaml
		#wget -P ${var_k8s_cfg_dir}/  https://raw.githubusercontent.com/projectcalico/calico/${var_calico_version}/manifests/custom-resources.yaml
		#sed -i 's/cidr: 192\.168\.0\.0\/16/cidr: 10.8.0.0\/16/g' ${var_k8s_cfg_dir}/custom-resources.yaml
		#kubectl create -f ${var_k8s_cfg_dir}/custom-resources.yaml
		
		kubectl get nodes
		
		echo -e "\nCommand to join worker nodes is located in ${var_k8s_cfg_dir}/worker-node-join-command !! \n"
		
		sleep 2
		
		clear
		
		echo -e "\nProceeding with post-installation configurations . . .\n"
		
		# Waiting for control plane to become ready
		while :
		do
			echo -e "\nWaiting for ${var_k8s_node_type} to get Ready . . .\n"
			if kubectl get nodes | grep -w " Ready " &>/dev/null
			then
				kubectl get nodes
				kubectl get pods -A
				break
			else
				kubectl get nodes
				kubectl get pods -A
				sleep 2
				continue
			fi
		done
		
		fn_check_internet_connectivity
		
		echo -e "\nInstalling CSI SMB drivers by remote internet connection . . .\n" 
		
		curl -skSL https://raw.githubusercontent.com/kubernetes-csi/csi-driver-smb/"${var_csi_smb_version}"/deploy/install-driver.sh | bash -s "${var_csi_smb_version}" --
			
		# Wait until all pods are running
			
		while :
		do
			echo -e "\nWaiting for CSI SMB pods creation to start . . .\n"
			if kubectl get pods --all-namespaces | grep csi-smb;then break;fi
			sleep 2
		done
			
		while :
		do
			echo -e "\nWaiting for all the required ${var_k8s_node_type} pods to come online . . .\n"
			if kubectl get pods --all-namespaces -o jsonpath='{.items[*].status.containerStatuses[*].ready}' | grep false &>/dev/nul
			then 
				kubectl get pods --all-namespaces
				sleep 5
				continue
			else 
				echo -e "\nAll the required pods for ${var_k8s_node_type} are now Running! \n"
				kubectl get pods --all-namespaces
				break
			fi
		done
		
		if [ -f /scripts_by_muthu/muthuks-server/k8s/k8s-setup-apply.sh ]
		then
			ln -s /scripts_by_muthu/muthuks-server/k8s/k8s-setup-apply.sh /usr/bin/k8s-apply
		fi
		
		if [ -f /scripts_by_muthu/muthuks-server/k8s/k8s-setup-delete.sh ]
		then
			ln -s /scripts_by_muthu/muthuks-server/k8s/k8s-setup-delete.sh /usr/bin/k8s-delete
		fi
		
		if [ -f /etc/systemd/system/configure-k8s-"${var_k8s_node_type}".service ]
		then
			systemctl disable configure-k8s-"${var_k8s_node_type}".service
		fi
		
		echo -e "\nCompleted stage-3 of k8s ${var_k8s_node_type} node configuration on ${var_k8s_host} ! \n"
		
		touch "${var_k8s_cfg_dir}"/completed-stage3
		
		echo -e "\nSuccessfully completed installation and configuration of k8s ${var_k8s_node_type} node! \n"
		
		kubectl get nodes
	fi
}

#### End of Function Definitions ####

fn_k8s_main_menu "${1}"

var_k8s_host=$(hostname -f)
var_k8s_cfg_dir="/root/configure-k8s"
var_logs_file="${var_k8s_cfg_dir}/logs-configure-k8s-${var_k8s_node_type}.log"

mkdir -p "${var_k8s_cfg_dir}"
touch "${var_logs_file}"

{
	echo -e "\nStarted service configure-k8s-${var_k8s_node_type} . . .\n"

	if grep -i -E "rhel|fedora" /etc/os-release &>/dev/null
	then
		echo -e "\nUpgrading all installed packages in the system if required . . .\n"
		fn_check_internet_connectivity
		dnf clean all
		dnf update --refresh -y
		echo -e "\nInstalling some required basic packages . . .\n"
		fn_check_internet_connectivity
		dnf install -y curl wget rsync jq
		fn_set_version_variables
		fn_stage1_configuration
		fn_stage2_for_redhat_based
	fi

	if grep -i -E "ubuntu|debian" /etc/os-release &>/dev/null
	then
		echo -e "\nUpgrading all installed packages in the system if required . . .\n"
		fn_check_internet_connectivity
		apt-get clean 
		apt-get update
		fn_check_internet_connectivity
		apt-get upgrade -y
		echo -e "\nInstalling some required basic packages . . .\n"
		fn_check_internet_connectivity
		apt-get install -y curl wget rsync gpg jq
		fn_set_version_variables
		fn_stage1_configuration
		fn_stage2_for_debian_based
	fi

	if grep -i "suse" /etc/os-release &>/dev/null
	then
		echo -e "\nUpgrading all installed packages in the system if required . . .\n"
		fn_check_internet_connectivity
		zypper clean -a 
		zypper refresh
		fn_check_internet_connectivity
		zypper update -y 
		echo -e "\nInstalling some basic required packages . . .\n"
		fn_check_internet_connectivity
		zypper install -y curl wget rsync jq
		fn_set_version_variables
		fn_stage1_configuration
		fn_stage2_for_suse_based 
	fi

	if [[ "${var_k8s_node_type}" == "ctrl-plane" ]]
	then
		fn_stage3_configuration
	else
		echo -e "Starting kubelet.service . . .\n"

		systemctl enable --now kubelet.service

		systemctl status kubelet.service

		echo -e "\nIgnore if kubelet.service service is not running! \n"

		echo -e "\nThe kubelet.service will start automatically when this ${var_k8s_node_type} node is joined with ctrl-plane node! \n"

		echo -e "\nSuccessfully completed installation and configuration of k8s "${var_k8s_version}" ${var_k8s_node_type} node! \n"

		echo -e "\nFrom ctrl-plane node,\nRun \"kubeadm token create --print-join-command\" to create join command.\n"

		echo -e "\nJoin the ${var_k8s_node_type} node ${var_k8s_host} with k8s cluster using above provided kubeadm join command.\n"

		if [ -f /etc/systemd/system/configure-k8s-"${var_k8s_node_type}".service ]
		then
        		systemctl disable configure-k8s-"${var_k8s_node_type}".service
		fi

	fi

} | tee -a /dev/tty0 "${var_logs_file}"

exit
