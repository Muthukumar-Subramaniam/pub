#!/bin/bash

if [[ "$1" == "-y" ]]
then
	:
else
	while :
	do
		echo
		read -r -p "Do you really want to run this script $(basename "$0") ? (yes/no) : " var_get_confirmation
		if [[ "$var_get_confirmation" == "yes" ]]
		then
			break
		elif [[ "$var_get_confirmation" == "no" ]]
		then
			echo -e "\nExiting without any changes!\n"
			exit
		else
			echo -e "\nInvalid Input!\n"
			continue
		fi
	done
fi

mkdir -p /root/configure-k8s-worker
touch /root/configure-k8s-worker/logs-configure-k8s-worker.log


{

fn_check_internet_connectivity() {
	while :
	do
		echo -e "\nChecking Internet connectivity as the next step requires it . . ."
		if ! ping -c 1 google.com &>/dev/null
		then 
			echo -e "\nInternet connection is down! "
			echo -e "Waiting for 15 seconds to check again . . .\n"
			sleep 15
			continue
		else
			echo -e "\nInternet connection is active.\n"
			break
		fi
	done
}

fn_set_variables() {

	var_k8s_host=$(hostname -f)
	var_k8s_cfg_dir='/root/configure-k8s-worker'
	var_logs_wget="${var_k8s_cfg_dir}/logs-configure-k8s-worker.log"

	fn_get_latest_version() {
		
		var_api_url="${1}"
		var_software_name="${2}"
		var_k8s_host="${3}"
		var_k8s_cfg_dir="${4}"
		var_git_repo_url="${5}"
		
		fn_check_internet_connectivity

		var_latest_version=$(curl -s -L "${var_api_url}" | jq -r '.tag_name' 2>>/dev/null | tr -d '[:space:]')

		if [ -z ${var_latest_version} ]
		then
			echo -e "\nFailed to fetch latest version of "${var_software_name}" ! \n"

			while :
			do
				echo "Login to the host ${var_k8s_host} via ssh and switch to directory ${var_k8s_cfg_dir}."
				echo "Refer : ${var_git_repo_url}"
				echo "Create a file ${var_software_name}_version.txt with the version in the format v*.*.*"
				echo "Waiting for 5 seconds to refer the file ${var_k8s_cfg_dir}/${var_software_name}_version . . ."
				sleep 5

				if [ -f "${var_k8s_cfg_dir}"/"${var_software_name}"_version ]
				then
					var_latest_version=$(cat "${var_k8s_cfg_dir}"/"${var_software_name}"_version | tr -d '[:space:]' | sed '/^$/d')
				else
					continue
				fi

				if [[ "${var_latest_version}" =~ v[[:digit:]]+\.[[:digit:]]+\.[[:digit:]]+ ]]
				then
					break
				else
					echo -e "\nIncorrect format of version in "${var_k8s_cfg_dir}"/"${var_software_name}"_version! "
					echo -e "The format should be vMAJOR.MINOR.PATCH ( Semantic Versioning )"
					echo -e "Current version mentioned : $(cat "${var_k8s_cfg_dir}"/"${var_software_name}"_version) \n"
					continue
				fi
			done
					
		fi
	}

	echo -e "Fetching latest version information of k8s . . . \n"
	fn_get_latest_version "https://api.github.com/repos/kubernetes/kubernetes/releases/latest" "k8s" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/kubernetes/kubernetes"
	var_k8s_version="${var_latest_version}"
	echo -e "Latest version of k8s is ${var_k8s_version} \n"

	echo -e "Fetching latest version information of containerd . . . \n"
	fn_get_latest_version "https://api.github.com/repos/containerd/containerd/releases/latest" "containerd" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/containerd/containerd"
	var_containerd_version="${var_latest_version}"
	echo -e "Latest version of containerd is ${var_containerd_version} \n"

	echo -e "Fetching latest version information of runc . . . \n"
	fn_get_latest_version "https://api.github.com/repos/opencontainers/runc/releases/latest" "runc" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/opencontainers/runc"
	var_runc_version="${var_latest_version}"
	echo -e "Latest version of runc is ${var_runc_version} \n"

}


fn_stage1_configuration() {

	var_k8s_host="${1}"
	var_k8s_cfg_dir="${2}"
	var_logs_wget="${3}"
	var_containerd_version="${4}"
	var_runc_version="${5}"
	
	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage1 ]
	then
		clear

		echo -e "\nStarting stage-1 of k8s worker node configuration on ${var_k8s_host} . . .\n"

		echo -e "\nLoading required kernel modules . . .\n"

		modprobe -vv overlay
		modprobe -vv br_netfilter

cat << EOF | tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF

		echo -e "\nLoading required kernel parameters . . .\n"

cat << EOF | tee /etc/sysctl.d/k8s.conf
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

		sysctl --system

		fn_check_internet_connectivity

		echo -e "\nDownloading container runtime containerd . . ."
		echo "(This might take some time depending on the internet speed)"

		mkdir "${var_k8s_cfg_dir}"/containerd

		wget -P "${var_k8s_cfg_dir}"/containerd/ https://github.com/containerd/containerd/releases/download/"${var_containerd_version}"/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz -a "${var_logs_wget}" 

		echo -e "\nConfiguring containerd . . .\n"

		tar Cxzvf "${var_k8s_cfg_dir}"/containerd/ "${var_k8s_cfg_dir}"/containerd/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz

		chmod +x "${var_k8s_cfg_dir}"/containerd/bin/*

		rsync -avPh "${var_k8s_cfg_dir}"/containerd/bin/ /usr/bin/

		mkdir -p /etc/containerd

		echo -e "\nChecking containerd version . . ."

		containerd --version

		containerd config default > /etc/containerd/config.toml

		sed -i "/SystemdCgroup/s/false/true/g" /etc/containerd/config.toml

		containerd config dump | grep SystemdCgroup

		fn_check_internet_connectivity

		echo -e "Downloading containerd.service file from github . . .\n"

		wget -P /etc/systemd/system/ https://raw.githubusercontent.com/containerd/containerd/main/containerd.service -a "${var_logs_wget}"

		sed -i  "/ExecStart=/s/\/usr\/local/\/usr/g" /etc/systemd/system/containerd.service

		echo -e "\nStarting the containerd.service . . .\n"

		systemctl daemon-reload

		systemctl enable --now containerd.service

		systemctl status containerd.service

		fn_check_internet_connectivity

		echo -e "\nDownloading low-level container runtime runc ( dependency of containerd ) . . ."
		echo "(This might take some time depending on the internet speed)"

		wget -P /usr/bin/ https://github.com/opencontainers/runc/releases/download/"${var_runc_version}"/runc.amd64 -a "${var_logs_wget}" 

		echo -e "\nConfiguring runc . . .\n"
		mv /usr/bin/runc.amd64 /usr/bin/runc
		chmod +x /usr/bin/runc

		runc --version

		echo -e "\nCompleted stage-1 of k8s worker node configuration on ${var_k8s_host} ! \n"

		touch "${var_k8s_cfg_dir}"/completed-stage1

		sleep 2

	fi
}


fn_stage2_for_redhat_based() {

	var_k8s_host="${1}"
	var_k8s_cfg_dir="${2}"
	var_k8s_version="${3}"

	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage2 ]
	then

		clear

		echo -e "\nStarting stage-2 of k8s worker node configuration on ${var_k8s_host} . . .\n"

		fn_check_internet_connectivity

		echo -e "\nConfiguring k8s rpm repository and installing required packages . . .\n"

		var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
		var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
		var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"

cat << EOF | tee /etc/yum.repos.d/k8s.repo
[k8s-${var_k8s_version_major_minor}]
name=k8s-${var_k8s_version_major_minor}
baseurl=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/repodata/repomd.xml.key
exclude=kubelet kubeadm kubectl
EOF

		dnf makecache

		fn_check_internet_connectivity

		dnf install -y kubelet kubeadm kubectl --disableexcludes=k8s-"${var_k8s_version_major_minor}"

		echo -e "\nCompleted stage-2 of k8s worker node configuration on ${var_k8s_host} ! \n"

		touch "${var_k8s_cfg_dir}"/completed-stage2
	fi
}


fn_stage2_for_debian_based() {

	var_k8s_host="${1}"
	var_k8s_cfg_dir="${2}"
	var_k8s_version="${3}"

	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage2 ]
	then
		clear

		echo -e "\nStarting stage-2 of k8s worker node configuration on ${var_k8s_host} . . .\n"

		fn_check_internet_connectivity

		echo -e "\nConfiguring k8s deb repository and installing required packages . . .\n"

		var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
		var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
		var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"

		echo "deb [signed-by=/etc/apt/keyrings/k8s-apt-keyring-${var_k8s_version_major_minor}.gpg] https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/deb/ /" | sudo tee /etc/apt/sources.list.d/k8s.list

		curl -fsSL https://pkgs.k8s.io/core:/stable:/"${var_k8s_version_major_minor}"/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/k8s-apt-keyring-"${var_k8s_version_major_minor}".gpg


		fn_check_internet_connectivity

		apt-get update

		fn_check_internet_connectivity

		apt-get install -y kubelet kubeadm kubectl

		apt-mark hold kubelet kubeadm kubectl

		echo -e "\nCompleted stage-2 of k8s worker node configuration on ${var_k8s_host} ! \n"

		touch "${var_k8s_cfg_dir}"/completed-stage2
	fi
}


fn_stage2_for_suse_based() {

	var_k8s_host="${1}"
	var_k8s_cfg_dir="${2}"
	var_k8s_version="${3}"

	if [ ! -f "${var_k8s_cfg_dir}"/completed-stage2 ]
	then
		clear

		echo -e "\nStarting stage-2 of k8s worker node configuration on ${var_k8s_host} . . .\n"

		fn_check_internet_connectivity

		echo -e "\nConfiguring k8s rpm repository and installing required packages . . .\n"

		var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
		var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
		var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"

cat <<EOF | tee /etc/zypp/repos.d/k8s.repo
[k8s-${var_k8s_version_major_minor}]
name=k8s-${var_k8s_version_major_minor}
baseurl=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/repodata/repomd.xml.key
[conntrack-for-suse]
name=conntrack-for-suse
baseurl=https://ks-manager-provided-web-server-name/k8s-install/suse/rpm/
enabled=1
gpgcheck=0
EOF

		fn_check_internet_connectivity

		zypper --gpg-auto-import-keys refresh

		fn_check_internet_connectivity
		
		zypper install -y kubeadm kubectl kubelet	

		zypper addlock kubeadm kubectl kubelet

		zypper ll

		fi

		echo -e "\nCompleted stage-2 of k8s worker node configuration on ${var_k8s_host} ! \n"

		touch "${var_k8s_cfg_dir}"/completed-stage2
	fi
}

fn_recursive_stage1_configuration() {
	fn_stage1_configuration "${var_k8s_host}" "${var_k8s_cfg_dir}" "${var_logs_wget}" "${var_containerd_version}" "${var_runc_version}"
}

echo -e "\nStarted service configure-k8s-worker . . .\n"

if grep -i -E "rhel|fedora" /etc/os-release &>/dev/null
then
	echo -e "\nUpgrading all installed packages in the system if required . . .\n"
	fn_check_internet_connectivity
	dnf clean all
	dnf update --refresh -y
	echo -e "\nInstalling some required basic packages . . .\n"
	fn_check_internet_connectivity
	dnf install -y curl wget rsync jq
	fn_set_variables
	fn_recursive_stage1_configuration
	fn_stage2_for_redhat_based "${var_k8s_host}" "${var_k8s_cfg_dir}" "${var_k8s_version}"
fi

if grep -i -E "ubuntu|debian" /etc/os-release &>/dev/null
then
	echo -e "\nUpgrading all installed packages in the system if required . . .\n"
	fn_check_internet_connectivity
	apt-get clean 
	apt-get update
	fn_check_internet_connectivity
	apt-get upgrade -y
	echo -e "\nInstalling some required basic packages . . .\n"
	fn_check_internet_connectivity
	apt-get install -y curl wget rsync gpg jq
	fn_set_variables
	fn_recursive_stage1_configuration
	fn_stage2_for_debian_based "${var_k8s_host}" "${var_k8s_cfg_dir}" "${var_k8s_version}"
fi

if grep -i "suse" /etc/os-release &>/dev/null
then
	echo -e "\nUpgrading all installed packages in the system if required . . .\n"
	fn_check_internet_connectivity
	zypper clean -a 
	zypper refresh
	fn_check_internet_connectivity
	zypper update -y 
	echo -e "\nInstalling some basic required packages . . .\n"
	fn_check_internet_connectivity
	zypper install -y curl wget rsync jq
	fn_set_variables
	fn_recursive_stage1_configuration
	fn_stage2_for_suse_based "${var_k8s_host}" "${var_k8s_cfg_dir}" "${var_k8s_version}" 
fi

echo -e "Starting kubelet.service . . .\n"

systemctl enable --now kubelet.service

systemctl status kubelet.service

echo -e "\nIgnore if kubelet.service service is not running! \n"

echo -e "\nThe kubelet.service will start automatically when this worker node is joined with ctrl-plane node! \n"

echo -e "\nSuccessfully completed installation and configuration of k8s "${var_k8s_version}" worker node! \n"

echo -e "\nFrom ctrl-plane node,\nRun \"kubeadm token create --print-join-command\" to create join command.\n"

echo -e "\nJoin the worker node ${var_k8s_host} with k8s cluster using above provided kubeadm join command.\n"

if [ -f /etc/systemd/system/configure-k8s-worker.service ]
then
	systemctl disable configure-k8s-worker.service
fi


} | tee -a /dev/tty0 /root/configure-k8s-worker/logs-configure-k8s-worker.log
