
fn_get_latest_version() {

	var_api_url="${1}"
	var_software_name="${2}"

	var_latest_version=$(curl -s -L "${var_api_url}" | jq -r '.tag_name' 2>>/dev/null | tr -d '[:space:]')

	if [ -z ${var_latest_version} ]
	then
		echo -e "\nFailed to fetch latest version of ${var_software_name} ! \n"
	else
		echo -e "\nLatest version of ${var_software_name} is ${var_latest_version} \n"
	fi
}

echo -e "Fetching latest version information of k8s . . . \n"
fn_get_latest_version "https://api.github.com/repos/kubernetes/kubernetes/releases/latest" "k8s"

echo -e "Fetching latest version information of containerd . . . \n"
fn_get_latest_version "https://api.github.com/repos/containerd/containerd/releases/latest" "containerd"

echo -e "Fetching latest version information of runc . . . \n"
fn_get_latest_version "https://api.github.com/repos/opencontainers/runc/releases/latest" "runc" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/opencontainers/runc"
var_runc_version="${var_latest_version}"
echo -e "Latest version of runc is ${var_runc_version} \n"

echo -e "Fetching latest version information of calico . . . \n"
fn_get_latest_version "https://api.github.com/repos/projectcalico/calico/releases/latest" "calico" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/projectcalico/calico"
var_calico_version="${var_latest_version}"
echo -e "Latest version of calico is ${var_calico_version} \n"

echo -e "Fetching latest version information csi-driver-smb . . . \n"
fn_get_latest_version "https://api.github.com/repos/kubernetes-csi/csi-driver-smb/releases/latest" "csi-driver-smb" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/kubernetes-csi/csi-driver-smb"
var_csi_smb_version="${var_latest_version}"
echo -e "Latest version of csi-driver-smb is ${var_csi_smb_version} \n"
