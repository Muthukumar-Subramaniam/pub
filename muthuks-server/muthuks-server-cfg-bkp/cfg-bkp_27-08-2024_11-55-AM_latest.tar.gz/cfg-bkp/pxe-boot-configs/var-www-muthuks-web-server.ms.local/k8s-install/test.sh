#!/bin/bash

fn_get_latest_version() {

	var_api_url="${1}"
	var_software_name="${2}"
	var_k8s_host="${3}"
	var_k8s_cfg_dir="${4}"
	var_git_repo_url="${5}"

	var_latest_version=$(curl -s -L "${var_api_url}" | jq -r '.tag_name' 2>>/dev/null | tr -d '[:space:]')

	if [[-z ${var_latest_version} || ! grep -o "v*.*.*" <<< "${var_latest_version}" &>/dev/null ]]
	then
		echo -e "\nFailed to fetch latest version of "${var_software_name}" ! \n"

		while :
		do
			echo "Login to the host ${var_k8s_host} via ssh and switch to directory ${var_k8s_cfg_dir}."
			echo "Refer : ${var_git_repo_url}"
			echo "Create a file ${var_software_name}_version.txt with the version in the format v*.*.*"
			echo "Waiting for 10 seconds to refer the file ${var_k8s_cfg_dir}/${var_software_name}_version . . ."
			sleep 10

			if grep -o "v*.*.*" "${var_k8s_cfg_dir}"/"${var_software_name}"_version &>/dev/null
			then
				var_latest_version=$(cat "${var_k8s_cfg_dir}"/"${var_software_name}"_version)
				break
			else
				continue
			fi
		done
		
	fi
}

var_k8s_host=$(hostname -f)
var_k8s_cfg_dir='/root/configure-k8s-ctrl-plane'

echo -e "Fetching latest version information of k8s . . . \n"
fn_get_latest_version "https://apii.github.com/repos/kubernetes/kubernetes/releases/latest" "k8s" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/kubernetes/kubernetes"
var_k8s_version="${var_latest_version}"
echo -e "Latest version of k8s is ${var_k8s_version} \n"

echo -e "Fetching latest version information of containerd . . . \n"
fn_get_latest_version "https://api.github.com/repos/containerd/containerd/releases/latest" "containerd" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/containerd/containerd"
var_containerd_version="${var_latest_version}"
echo -e "Latest version of containerd is ${var_containerd_version} \n"

echo -e "Fetching latest version information of runc . . . \n"
fn_get_latest_version "https://api.github.com/repos/opencontainers/runc/releases/latest" "runc" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/opencontainers/runc"
var_runc_version="${var_latest_version}"
echo -e "Latest version of runc is ${var_runc_version} \n"

echo -e "Fetching latest version information of calico . . . \n"
fn_get_latest_version "https://api.github.com/repos/projectcalico/calico/releases/latest" "calico" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/projectcalico/calico"
var_calico_version="${var_latest_version}"
echo -e "Latest version of calico is ${var_calico_version} \n"

echo -e "Fetching latest version information csi-driver-smb . . . \n"
fn_get_latest_version "https://api.github.com/repos/kubernetes-csi/csi-driver-smb/releases/latest" "csi_smb" "${var_k8s_host}" "${var_k8s_cfg_dir}" "https://github.com/kubernetes-csi/csi-driver-smb"
var_csi_smb_version="${var_latest_version}"
echo -e "Latest version of csi-driver-smb is ${var_csi_smb_version} \n"
