#!/bin/bash
var_k8s_rpm_repo_dir='/var/www/muthuks-web-server.ms.local/k8s-install/local/rpm'
var_k8s_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/latest-k8s-version.txt)
var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"

echo -e "\nCreating ${var_k8s_rpm_repo_dir} if not already present . . .\n"
mkdir -p "${var_k8s_rpm_repo_dir}"

echo -e "\nAdding k8s Repository . . .\n"
cat << EOF | tee /etc/yum.repos.d/k8s-"${var_k8s_version_major_minor}".repo
[k8s-${var_k8s_version_major_minor}]
name=k8s-${var_k8s_version_major_minor}
baseurl=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/rpm/repodata/repomd.xml.key
exclude=kubelet kubeadm kubectl cri-tools kubernetes-cni
EOF

echo -e "\nCleaning up existing dnf package caches . . .\n"
dnf clean all

echo -e "\nUpdating dnf package cache . . .\n"
dnf makecache

echo -e "\nDownloading k8s rpm packages to ${var_k8s_rpm_repo_dir} . . .\n"
dnf download -y --arch x86_64 kubelet kubeadm kubectl cri-tools kubernetes-cni --disableexcludes=k8s-"${var_k8s_version_major_minor}" --downloaddir="${var_k8s_rpm_repo_dir}"

if ! dnf list installed createrepo_c &>/dev/null
then
	echo -e "\nInstalling createrepo as its not installed . . .\n"
	dnf install -y createrepo_c
fi

echo -e "\nCreating local k8s repository on ${var_k8s_rpm_repo_dir} . . .\n"
createrepo "${var_k8s_rpm_repo_dir}"
