#!/bin/bash
var_k8s_rpm_repo_dir='/var/www/muthuks-web-server.ms.local/k8s-install/local/rpm'
var_k8s_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/latest-k8s-version.txt)
dnf download --arch x86_64 kubelet kubeadm kubectl cri-tools kubernetes-cni --disableexcludes=k8s-v1.31
