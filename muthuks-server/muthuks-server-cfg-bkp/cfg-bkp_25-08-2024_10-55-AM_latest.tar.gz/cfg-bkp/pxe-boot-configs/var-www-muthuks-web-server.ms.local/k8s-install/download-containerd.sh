#!/bin/bash
var_containerd_version=_
var_containerd_dir='/var/www/muthuks-web-server.ms.local/k8s-install/containerd'
