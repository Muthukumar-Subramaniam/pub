#!/bin/bash
var_runc_version='v1.1.13'
var_runc_dir="/var/www/muthuks-web-server.ms.local/k8s-install/runc/${var_runc_version}"
mkdir -p "${var_runc_dir}"
wget -P "${var_runc_dir}/" https://github.com/opencontainers/runc/releases/download/"${var_runc_version}"/runc.amd64
