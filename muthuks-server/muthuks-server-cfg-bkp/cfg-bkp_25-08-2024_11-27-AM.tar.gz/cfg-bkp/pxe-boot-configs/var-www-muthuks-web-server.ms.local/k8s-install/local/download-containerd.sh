#!/bin/bash
var_containerd_version='v1.7.20'
var_containerd_dir="/var/www/muthuks-web-server.ms.local/k8s-install/containerd/${var_containerd_version}"
mkdir -p "${var_containerd_dir}"
wget -P "${var_containerd_dir}/" https://github.com/containerd/containerd/releases/download/"${var_containerd_version}"/containerd-"${var_containerd_version:1}"-linux-amd64.tar.gz
