#!/bin/bash
var_runc_version='v1.1.13'
var_runc_dir="/var/www/muthuks-web-server.ms.local/k8s-install/local/runc/${var_runc_version}"
mkdir -p "${var_runc_dir}"
wget https://github.com/opencontainers/runc/releases/download/"${var_runc_version}"/runc.amd64 -O "${var_runc_dir}/"runc.amd64
echo "${var_runc_version}" >/var/www/muthuks-web-server.ms.local/k8s-install/local/runc/current-runc-version.txt
