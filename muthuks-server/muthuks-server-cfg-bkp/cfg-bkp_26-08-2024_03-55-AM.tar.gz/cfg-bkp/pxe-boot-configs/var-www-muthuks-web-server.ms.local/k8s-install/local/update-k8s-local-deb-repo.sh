#!/bin/bash
var_test_ubuntu_server="prod-vm2.ms.local"
var_k8s_deb_repo_dir='/var/www/muthuks-web-server.ms.local/k8s-install/local/deb'
var_k8s_version=$(cat /var/www/muthuks-web-server.ms.local/k8s-install/latest-k8s-version.txt)
var_k8s_version_major=$(echo "${var_k8s_version}" | cut -d "." -f 1)
var_k8s_version_minor=$(echo "${var_k8s_version}" | cut -d "." -f 2)
var_k8s_version_major_minor="${var_k8s_version_major}.${var_k8s_version_minor}"

mkdir -p "${var_k8s_deb_repo_dir}"

if ! nc -vzw2 "${var_test_ubuntu_server}" 22
then
	echo -e "\nUnable to connect to test ubuntu server ${var_test_ubuntu_server} via ssh ! \n"
	echo -e "\nPlease check and try again ! \n"
	exit
fi

ssh-keygen -R "${var_test_ubuntu_server}"

ssh -o StrictHostKeyChecking=accept-new root@"${var_test_ubuntu_server}" "mkdir -p /root/deb"

ssh root@"${var_test_ubuntu_server}" "echo 'APT::Sandbox::User \"root\";' >>/etc/apt/apt.conf.d/10sandbox"

ssh root@"${var_test_ubuntu_server}" "apt-get update"

ssh root@"${var_test_ubuntu_server}" "apt-get install -y dpkg-dev"

ssh root@"${var_test_ubuntu_server}" "echo \"deb [signed-by=/etc/apt/keyrings/k8s-apt-keyring-${var_k8s_version_major_minor}.gpg] https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/deb/ /\" | tee /etc/apt/sources.list.d/k8s-${var_k8s_version_major_minor}.list"

echo "hai, is this here?"
ssh root@"${var_test_ubuntu_server}" "curl -fsSL https://pkgs.k8s.io/core:/stable:/${var_k8s_version_major_minor}/deb/Release.key | gpg --dearmor -o /etc/apt/keyrings/k8s-apt-keyring-${var_k8s_version_major_minor}.gpg"

ssh root@"${var_test_ubuntu_server}" "apt-get update"

ssh root@"${var_test_ubuntu_server}" "cd /root/deb && apt-get download kubectl kubeadm kubelet cri-tools kubernetes-cni"

ssh root@"${var_test_ubuntu_server}" "cd /root/deb && dpkg-scanpackages -m . > Packages"

rm -rf "${var_k8s_deb_repo_dir}"

rsync -avPh root@"${var_test_ubuntu_server}":/root/deb "${var_k8s_deb_repo_dir}"
