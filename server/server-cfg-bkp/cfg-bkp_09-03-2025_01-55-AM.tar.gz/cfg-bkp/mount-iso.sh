#!/bin/bash
###Mounts ISO files under web share
###mkdir -p /var/www/server.ms.local/{{rhel,rocky,almalinux,oraclelinux}-9,ubuntu-24-04,opensuse-15}
#mount -o loop,uid=muthuks,gid=muthuks /downloads/rhel-9.5-x86_64-boot.iso /var/www/server.ms.local/rhel-9
#mount -o loop,uid=muthuks,gid=muthuks /downloads/Rocky-9.5-x86_64-boot.iso /var/www/server.ms.local/rocky-9
#mount -o loop,uid=muthuks,gid=muthuks /downloads/OracleLinux-R9-U5-x86_64-boot.iso /var/www/server.ms.local/oraclelinux-9
mount -o loop,uid=muthuks,gid=muthuks /downloads/AlmaLinux-9.5-x86_64-boot.iso /var/www/server.ms.local/almalinux-9
mount -o loop,uid=muthuks,gid=muthuks /downloads/openSUSE-Leap-15.6-DVD-x86_64-Build709.1-Media.iso /var/www/server.ms.local/opensuse-15
#mount -o loop,uid=muthuks,gid=muthuks /downloads/ubuntu-24.04.2-live-server-amd64.iso /var/www/server.ms.local/ubuntu-24-04
